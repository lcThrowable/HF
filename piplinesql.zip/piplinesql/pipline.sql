update ldcode set codename='=10' where codetype='pipeline_rate' and codename='≥10';
update ldcode set codename='=20' where codetype='pipeline_rate' and codename='≥20';
update ldcode set codename='=30' where codetype='pipeline_rate' and codename='≥30';
update ldcode set codename='=40' where codetype='pipeline_rate' and codename='≥40';
update ldcode set codename='=50' where codetype='pipeline_rate' and codename='≥50';
update ldcode set codename='=60' where codetype='pipeline_rate' and codename='≥60';
update ldcode set codename='=70' where codetype='pipeline_rate' and codename='≥70';
update ldcode set codename='=80' where codetype='pipeline_rate' and codename='≥80';
update ldcode set codename='=90' where codetype='pipeline_rate' and codename='≥90';
insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('pipeline_rate', '100', '=100', null, '10', null);

update ldcode set codename='=10' where codetype='pipeline_Oprate' and codename='≥10';
update ldcode set codename='=20' where codetype='pipeline_Oprate' and codename='≥20';
update ldcode set codename='=30' where codetype='pipeline_Oprate' and codename='≥30';
update ldcode set codename='=40' where codetype='pipeline_Oprate' and codename='≥40';
update ldcode set codename='=50' where codetype='pipeline_Oprate' and codename='≥50';
update ldcode set codename='=60' where codetype='pipeline_Oprate' and codename='≥60';
update ldcode set codename='=70' where codetype='pipeline_Oprate' and codename='≥70';
update ldcode set codename='=80' where codetype='pipeline_Oprate' and codename='≥80';
update ldcode set codename='=90' where codetype='pipeline_Oprate' and codename='≥90';
insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('pipeline_Oprate', '100', '=100', null, '10', null);

update elementsofcontrol set validitem=''where SID='PIPLINEINFO' and ID='mobile';
commit;